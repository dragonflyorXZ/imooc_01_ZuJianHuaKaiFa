package com.youdu.module.course;

import com.youdu.module.BaseModel;

/**
 * @author: vision
 * @function:
 * @date: 16/9/8
 */
public class CourseFooterRecommandValue extends BaseModel {
    public String imageUrl;
    public String name;
    public String price;
    public String zan;
    public String courseId;
}
