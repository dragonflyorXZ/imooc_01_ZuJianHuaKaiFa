package com.youdu.module.mina;

import com.youdu.module.BaseModel;

/**
 * Created by renzhiqiang on 16/8/20.
 */
public class MinaMessage extends BaseModel {

    public int type;
    public String title;
    public String contentUrl;
    public String dayTime;
    public String site;
    public String photoUrl;
    public String imageUrl;
    public String info;
    public String qq;
}
