package com.youdu.module.user;

import com.youdu.module.BaseModel;

/**
 * Created by renzhiqiang on 15/11/20.
 */
public class UserContent extends BaseModel {

    public String userId; //用户唯一标识符
    public String photoUrl;
    public String name;
    public String tick;
    public String mobile;
    public String platform;
}
